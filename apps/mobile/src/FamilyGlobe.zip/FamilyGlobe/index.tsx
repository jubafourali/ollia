import React, {
  useCallback, useEffect, useMemo, useRef, useState,
} from "react";
import {
  Animated, Easing, LayoutChangeEvent, Platform,
  Pressable, StyleSheet, Text, View,
} from "react-native";
import { GLView, ExpoWebGLRenderingContext } from "expo-gl";
import * as THREE from "three";
import { Renderer } from "expo-three";
import { PresenceToken } from "./PresenceToken";
import {
  ResolvedPin, GlobeMember,
} from "./types";
import {
  resolveMembers, formatLastSeen, STATUS_LABEL,
  STATUS_PIN_COLOR, restingRotation, projectLatLng,
  STATUS_BREATH,
} from "./globeUtils";

import BRAND from "@/constants/colors";
import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";

// ── Constants ──────────────────────────────────────────────────────────────
const GLOBE_HPAD  = 20;
const GLOBE_H     = 260;
const AUTO_ROT_SPD = 0.008;
const INERTIA_DECAY = 0.90;
const INERTIA_THRESH = 0.001;
const INERTIA_RESUME_MS = 1800;
const PANEL_H = 220;

// ── Props ──────────────────────────────────────────────────────────────────
type Props = {
  members: GlobeMember[];
  meRegion?: string;
};

// ── Component ──────────────────────────────────────────────────────────────
export function FamilyGlobe({ members, meRegion }: Props) {
  const [glSize, setGlSize]     = useState({ w: 320, h: GLOBE_H });
  const [pins, setPins]         = useState<ResolvedPin[]>([]);
  const [selected, setSelected] = useState<ResolvedPin | null>(null);
  const [panelAnim]             = useState(() => new Animated.Value(0));
  const [breathAnims]           = useState<Record<string, Animated.Value>>({});

  // GL / Three.js refs
  const rendererRef  = useRef<Renderer | null>(null);
  const sceneRef     = useRef<THREE.Scene | null>(null);
  const cameraRef    = useRef<THREE.PerspectiveCamera | null>(null);
  const globeRef     = useRef<THREE.Mesh | null>(null);
  const rafRef       = useRef<number>(0);
  const glRef        = useRef<ExpoWebGLRenderingContext | null>(null);

  // Rotation state
  const rotRef        = useRef({ y: 0, x: 0 });          // euler radians
  const velRef        = useRef({ y: 0, x: 0 });
  const isDragging    = useRef(false);
  const lastTouch     = useRef<{ x: number; y: number } | null>(null);
  const lastDragEnd   = useRef(0);
  const restingRot    = useRef<[number, number]>([0, 20]);

  // Pin projected screen positions (updated every frame)
  const [pinScreenPos, setPinScreenPos] = useState<Record<string, { x: number; y: number; visible: boolean }>>({});

  // ── Resolve members → pins ──────────────────────────────────────────────
  useEffect(() => {
    const resolved = resolveMembers(members, meRegion);
    setPins(resolved);
    const [lng, lat] = restingRotation(resolved);
    restingRot.current = [lng, lat];
  }, [members, meRegion]);

  // ── Breath animations per pin ───────────────────────────────────────────
  useEffect(() => {
    pins.forEach(p => {
      if (!breathAnims[p.id]) {
        const av = new Animated.Value(0);
        breathAnims[p.id] = av;
        const cfg = STATUS_BREATH[p.status] ?? STATUS_BREATH.inactive;
        Animated.loop(
          Animated.sequence([
            Animated.timing(av, { toValue: 1, duration: cfg.period / 2, useNativeDriver: true, easing: Easing.inOut(Easing.sin) }),
            Animated.timing(av, { toValue: 0, duration: cfg.period / 2, useNativeDriver: true, easing: Easing.inOut(Easing.sin) }),
          ])
        ).start();
      }
    });
  }, [pins]);

  // ── GL context setup ────────────────────────────────────────────────────
  const onContextCreate = useCallback(async (gl: ExpoWebGLRenderingContext) => {
    glRef.current = gl;
    const { drawingBufferWidth: w, drawingBufferHeight: h } = gl;

    const renderer = new Renderer({ gl });
    renderer.setSize(w, h);
    renderer.setClearColor(0x00000000, 0);
    rendererRef.current = renderer;

    const scene  = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(38, w / h, 0.1, 100);
    camera.position.z = 2.6;
    cameraRef.current = camera;

    // ── Lighting ──
    const ambient = new THREE.AmbientLight(0xfff8ec, 0.72);
    scene.add(ambient);
    const sun = new THREE.DirectionalLight(0xffeedd, 1.2);
    sun.position.set(3, 2, 4);
    scene.add(sun);
    const fill = new THREE.DirectionalLight(0xf8e8d0, 0.28);
    fill.position.set(-2, -1, -2);
    scene.add(fill);

    // ── Globe sphere ──
    const geo = new THREE.SphereGeometry(1, 64, 64);
    const mat = new THREE.MeshPhongMaterial({
      color:     0xfdf4e8,
      specular:  0xf5c98a,
      shininess: 28,
      transparent: false,
    });
    const globe = new THREE.Mesh(geo, mat);
    scene.add(globe);
    globeRef.current = globe;

    // ── Latitude / longitude grid lines ──
    const gridMat = new THREE.LineBasicMaterial({ color: 0xc8a86a, transparent: true, opacity: 0.20 });
    const gridGeo = new THREE.BufferGeometry();
    const gridVerts: number[] = [];
    const D2R = Math.PI / 180;

    // Latitude lines every 30°
    for (let lat = -60; lat <= 60; lat += 30) {
      for (let lon = 0; lon < 360; lon += 3) {
        const push = (lo: number) => {
          const phi = lat * D2R, lam = lo * D2R;
          gridVerts.push(Math.cos(phi) * Math.cos(lam), Math.sin(phi), Math.cos(phi) * Math.sin(lam));
        };
        push(lon); push(lon + 3);
      }
    }
    // Longitude lines every 30°
    for (let lon = 0; lon < 360; lon += 30) {
      for (let lat = -90; lat < 90; lat += 3) {
        const push = (la: number) => {
          const phi = la * D2R, lam = lon * D2R;
          gridVerts.push(Math.cos(phi) * Math.cos(lam), Math.sin(phi), Math.cos(phi) * Math.sin(lam));
        };
        push(lat); push(lat + 3);
      }
    }
    gridGeo.setAttribute("position", new THREE.Float32BufferAttribute(gridVerts, 3));
    scene.add(new THREE.LineSegments(gridGeo, gridMat));

    // ── Atmosphere halo (slightly larger, transparent warm sphere) ──
    const atmGeo = new THREE.SphereGeometry(1.06, 32, 32);
    const atmMat = new THREE.MeshPhongMaterial({
      color: 0xf59e0b, transparent: true, opacity: 0.065, side: THREE.BackSide,
    });
    scene.add(new THREE.Mesh(atmGeo, atmMat));

    // ── Render loop ──
    const D2Rr = Math.PI / 180;
    const loop = () => {
      rafRef.current = requestAnimationFrame(loop);

      const rot = rotRef.current;
      const vel = velRef.current;
      const rest = restingRot.current;

      if (!isDragging.current) {
        const sinceEnd = Date.now() - lastDragEnd.current;
        const hasInertia = Math.abs(vel.y) > INERTIA_THRESH || Math.abs(vel.x) > INERTIA_THRESH;

        if (hasInertia) {
          rot.y += vel.y;
          rot.x = Math.max(-70, Math.min(70, rot.x + vel.x));
          velRef.current = { y: vel.y * INERTIA_DECAY, x: vel.x * INERTIA_DECAY };
        } else if (sinceEnd > INERTIA_RESUME_MS) {
          rot.y += AUTO_ROT_SPD;
        }
      }

      if (globeRef.current) {
        globeRef.current.rotation.y = rot.y * D2Rr;
        globeRef.current.rotation.x = rot.x * D2Rr;
      }

      renderer.render(scene, camera);
      gl.endFrameEXP();

      // Project pins to screen coords
      if (cameraRef.current && pins.length > 0) {
        const proj: Record<string, { x: number; y: number; visible: boolean }> = {};
        const W = glSize.w, H = GLOBE_H;
        const D2Rr2 = Math.PI / 180;

        for (const p of pins) {
          const result = projectLatLng(
            p.lat, p.lng,
            -rot.y,   // rotLng (negate because globe Y rotation is westward)
            -rot.x,   // rotLat
            W / 2, H / 2,
            (Math.min(W, H) / 2) * 0.88,
          );
          proj[p.id] = result;
        }
        setPinScreenPos(proj);
      }
    };
    loop();
  }, [pins, glSize]);

  // ── Cleanup on unmount ──────────────────────────────────────────────────
  useEffect(() => {
    return () => {
      cancelAnimationFrame(rafRef.current);
      rendererRef.current?.dispose?.();
    };
  }, []);

  // ── Touch handlers ──────────────────────────────────────────────────────
  const onTouchStart = useCallback((e: any) => {
    const t = e.nativeEvent.touches?.[0] ?? e.nativeEvent;
    isDragging.current  = true;
    lastTouch.current   = { x: t.pageX, y: t.pageY };
    velRef.current      = { y: 0, x: 0 };
  }, []);

  const onTouchMove = useCallback((e: any) => {
    const t = e.nativeEvent.touches?.[0] ?? e.nativeEvent;
    if (!isDragging.current || !lastTouch.current) return;
    const dx = t.pageX - lastTouch.current.x;
    const dy = t.pageY - lastTouch.current.y;
    rotRef.current.y  += dx * 0.35;
    rotRef.current.x   = Math.max(-70, Math.min(70, rotRef.current.x + dy * 0.35));
    velRef.current     = { y: dx * 0.25, x: dy * 0.25 };
    lastTouch.current  = { x: t.pageX, y: t.pageY };
  }, []);

  const onTouchEnd = useCallback(() => {
    isDragging.current  = false;
    lastTouch.current   = null;
    lastDragEnd.current = Date.now();
  }, []);

  // ── Pin tap ─────────────────────────────────────────────────────────────
  const onPinTap = useCallback((pin: ResolvedPin) => {
    setSelected(pin);
    Animated.spring(panelAnim, {
      toValue: 1, useNativeDriver: true, bounciness: 4,
    }).start();
  }, [panelAnim]);

  const closePanel = useCallback(() => {
    Animated.timing(panelAnim, {
      toValue: 0, duration: 180, useNativeDriver: true, easing: Easing.out(Easing.cubic),
    }).start(() => setSelected(null));
  }, [panelAnim]);

  // ── Layout ──────────────────────────────────────────────────────────────
  const onLayout = useCallback((e: LayoutChangeEvent) => {
    const { width } = e.nativeEvent.layout;
    setGlSize({ w: width, h: GLOBE_H });
  }, []);

  const panelTranslate = panelAnim.interpolate({
    inputRange: [0, 1], outputRange: [PANEL_H + 20, 0],
  });
  const panelOpacity = panelAnim.interpolate({
    inputRange: [0, 0.3, 1], outputRange: [0, 0.8, 1],
  });

  const hasPins = pins.length > 0;

  return (
    <View style={styles.wrapper} onLayout={onLayout}>
      {/* ── Globe canvas ── */}
      <View
        style={[styles.globeWrap, { width: glSize.w, height: GLOBE_H }]}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        onTouchCancel={onTouchEnd}
      >
        <GLView
          style={{ width: glSize.w, height: GLOBE_H }}
          onContextCreate={onContextCreate}
        />

        {/* ── Constellation lines (SVG overlay) ── */}
        {/* drawn via absolute positioned View – we skip SVG for lines to avoid import */}

        {/* ── Pin overlays ── */}
        {pins.map(pin => {
          const pos = pinScreenPos[pin.id];
          if (!pos?.visible) return null;
          const TOKEN_SIZE = 34;
          const halfToken  = TOKEN_SIZE / 2 + 5;
          return (
            <Pressable
              key={pin.id}
              style={[
                styles.pinWrap,
                { left: pos.x - halfToken, top: pos.y - halfToken },
              ]}
              onPress={() => onPinTap(pin)}
              hitSlop={10}
            >
              {breathAnims[pin.id] ? (
                <Animated.View style={{
                  opacity: breathAnims[pin.id].interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.72, 1.0],
                  }),
                  transform: [{
                    scale: breathAnims[pin.id].interpolate({
                      inputRange: [0, 1],
                      outputRange: [0.97, 1.06],
                    }),
                  }],
                }}>
                  <PresenceToken
                    relation={pin.relation}
                    pinColor={STATUS_PIN_COLOR[pin.status] ?? "#9ca3af"}
                    size={TOKEN_SIZE}
                    showRing={pin.status === "active" || pin.status === "recent"}
                    ringColor={STATUS_PIN_COLOR[pin.status]}
                  />
                </Animated.View>
              ) : (
                <PresenceToken
                  relation={pin.relation}
                  pinColor={STATUS_PIN_COLOR[pin.status] ?? "#9ca3af"}
                  size={TOKEN_SIZE}
                  showRing={pin.status === "active" || pin.status === "recent"}
                  ringColor={STATUS_PIN_COLOR[pin.status]}
                />
              )}
            </Pressable>
          );
        })}

        {/* Empty state hint */}
        {!hasPins && (
          <View style={styles.emptyHint} pointerEvents="none">
            <Text style={styles.emptyHintText}>
              Pins appear once members set their city
            </Text>
          </View>
        )}
      </View>

      {/* ── Member detail panel ── */}
      {selected && (
        <Animated.View
          style={[
            styles.panel,
            { transform: [{ translateY: panelTranslate }], opacity: panelOpacity },
          ]}
        >
          <View style={styles.panelHandle} />

          <View style={styles.panelRow}>
            <PresenceToken
              relation={selected.relation}
              pinColor={STATUS_PIN_COLOR[selected.status] ?? "#9ca3af"}
              size={52}
              showRing
              ringColor={STATUS_PIN_COLOR[selected.status]}
            />
            <View style={styles.panelInfo}>
              <Text style={styles.panelName}>{selected.name}</Text>
              <Text style={styles.panelRelation}>{selected.relation}</Text>
              {selected.region ? (
                <View style={styles.panelLocationRow}>
                  <Feather name="map-pin" size={11} color={BRAND.textMuted} />
                  <Text style={styles.panelLocation}>{selected.region}</Text>
                </View>
              ) : null}
            </View>
            <View style={styles.panelStatusWrap}>
              <View style={[styles.statusDot, { backgroundColor: STATUS_PIN_COLOR[selected.status] ?? "#9ca3af" }]} />
              <Text style={[styles.statusText, { color: STATUS_PIN_COLOR[selected.status] ?? "#9ca3af" }]}>
                {STATUS_LABEL[selected.status]}
              </Text>
            </View>
          </View>

          <View style={styles.panelMeta}>
            <View style={styles.metaItem}>
              <Feather name="clock" size={12} color={BRAND.textMuted} />
              <Text style={styles.metaLabel}>Last seen</Text>
              <Text style={styles.metaValue}>{formatLastSeen(selected.lastSeen)}</Text>
            </View>
            <View style={styles.metaDivider} />
            <View style={styles.metaItem}>
              <Feather name="check-circle" size={12} color={BRAND.textMuted} />
              <Text style={styles.metaLabel}>Check-in</Text>
              <Text style={styles.metaValue}>{formatLastSeen(selected.lastCheckInAt)}</Text>
            </View>
          </View>

          <View style={styles.panelActions}>
            <Pressable
              style={({ pressed }) => [styles.viewBtn, pressed && { opacity: 0.78 }]}
              onPress={() => {
                closePanel();
                router.push({ pathname: "/member/[id]", params: { id: selected.id } });
              }}
            >
              <Text style={styles.viewBtnText}>View full profile</Text>
              <Feather name="arrow-right" size={14} color={BRAND.white} />
            </Pressable>
            <Pressable
              style={({ pressed }) => [styles.closeBtn, pressed && { opacity: 0.65 }]}
              onPress={closePanel}
              hitSlop={8}
            >
              <Feather name="x" size={18} color={BRAND.textMuted} />
            </Pressable>
          </View>
        </Animated.View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    marginBottom: 12,
    borderRadius: 20,
    overflow: "hidden",
    backgroundColor: "#0d0905",
    borderWidth: 1,
    borderColor: `${BRAND.primary}28`,
  },
  globeWrap: {
    position: "relative",
    overflow: "hidden",
    backgroundColor: "#0d0905",
  },
  pinWrap: {
    position: "absolute",
    zIndex: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyHint: {
    position: "absolute",
    bottom: 12,
    left: 0,
    right: 0,
    alignItems: "center",
  },
  emptyHintText: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    color: "rgba(255,248,235,0.38)",
  },
  panel: {
    backgroundColor: BRAND.backgroundCard ?? "#FFFBEB",
    borderTopWidth: 1,
    borderTopColor: `${BRAND.primary}25`,
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 20,
  },
  panelHandle: {
    width: 36, height: 4,
    borderRadius: 2,
    backgroundColor: BRAND.borderLight ?? "#F0E2C4",
    alignSelf: "center",
    marginBottom: 14,
  },
  panelRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    marginBottom: 14,
  },
  panelInfo: { flex: 1, gap: 2 },
  panelName: {
    fontSize: 17,
    fontFamily: "Inter_700Bold",
    color: BRAND.text,
  },
  panelRelation: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: BRAND.textSecondary,
  },
  panelLocationRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 2,
  },
  panelLocation: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    color: BRAND.textMuted,
  },
  panelStatusWrap: {
    alignItems: "center",
    gap: 4,
  },
  statusDot: {
    width: 8, height: 8, borderRadius: 4,
  },
  statusText: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    textAlign: "center",
  },
  panelMeta: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: `${BRAND.primary}08`,
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: `${BRAND.primary}18`,
  },
  metaItem: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    flexWrap: "wrap",
  },
  metaLabel: {
    fontSize: 11,
    fontFamily: "Inter_500Medium",
    color: BRAND.textMuted,
  },
  metaValue: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    color: BRAND.textSecondary,
  },
  metaDivider: {
    width: 1, height: 24,
    backgroundColor: `${BRAND.primary}20`,
    marginHorizontal: 10,
  },
  panelActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  viewBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    backgroundColor: BRAND.primary,
    borderRadius: 12,
    paddingVertical: 12,
  },
  viewBtnText: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    color: BRAND.white ?? "#fff",
  },
  closeBtn: {
    width: 42, height: 42,
    borderRadius: 21,
    backgroundColor: `${BRAND.primary}12`,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: `${BRAND.primary}28`,
  },
});

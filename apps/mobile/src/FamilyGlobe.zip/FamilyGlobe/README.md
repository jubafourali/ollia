# FamilyGlobe — Installation & Integration

## 1. Install packages

```bash
npx expo install expo-gl expo-three three
```
`react-native-svg` is already installed.

## 2. Copy these files into your app

Copy the entire `components/FamilyGlobe/` folder into your project's `components/` directory.

## 3. Add to FamilyScreen.tsx

```tsx
// At the top, add this import:
import { FamilyGlobe } from "@/components/FamilyGlobe";

// In the <ScrollView> contentContainerStyle, add paddingTop: 0
// Then, as the FIRST child inside the ScrollView (before statusBanner):

<FamilyGlobe
  members={members}
  meRegion={
    travelMode && travelDestination
      ? travelDestination
      : myProfile?.region ?? ""
  }
/>
```

Full insertion point — replace:

```tsx
<ScrollView
  contentContainerStyle={[
    styles.list,
    Platform.OS === "web" && { paddingBottom: 34 },
  ]}
  ...
>
  <View style={styles.statusBanner}>
```

with:

```tsx
<ScrollView
  contentContainerStyle={[
    styles.list,
    Platform.OS === "web" && { paddingBottom: 34 },
  ]}
  ...
>
  <FamilyGlobe
    members={members}
    meRegion={
      travelMode && travelDestination
        ? travelDestination
        : myProfile?.region ?? ""
    }
  />
  <View style={styles.statusBanner}>
```

## 4. TypeScript

`FamilyMember` from your context is compatible — no changes needed.
If you get a type error on `members`, cast:

```tsx
import type { GlobeMember } from "@/components/FamilyGlobe/types";
// members satisfies GlobeMember[] already — same fields, no cast needed
```

## 5. Web (if you support it)

`expo-gl` doesn't run on web. Wrap the globe:

```tsx
import { Platform } from "react-native";
// In FamilyScreen.tsx:
{Platform.OS !== "web" && (
  <FamilyGlobe members={members} meRegion={...} />
)}
```

## What it does

- Spinning Three.js globe (cream/amber with latitude grid lines)
- Each family member with a known city gets a **Presence Token** pin
  (warm cream orb with frosted relation-based silhouette hint)
- Tap a pin → slide-up detail panel with last seen, check-in time, status
- "View full profile" navigates to `/member/[id]`
- Auto-rotation resumes after 1.8 s of idle; drag-inertia on release
- Status ring colors: active=green, recent=orange, away=purple, inactive=gray
- Members with unknown/empty regions are silently omitted from the globe
  (they still appear in the card list below)

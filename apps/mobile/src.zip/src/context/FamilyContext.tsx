import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAuth } from "@clerk/clerk-expo";
import * as WebBrowser from "expo-web-browser";
import { router } from "expo-router";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { AppState, AppStateStatus, Linking, Platform } from "react-native";
import { api, ApiCircleMember, ApiSafetyEvent, ApiPattern, setAuthTokenGetter } from "@/utils/api";
import {
  registerBackgroundActivity,
  unregisterBackgroundActivity,
  storeBackgroundToken,
  hasBackgroundLocationPermission,
  DETECTION_LABEL,
} from "@/services/backgroundActivity";
import * as BackgroundFetch from "expo-background-fetch";
import * as Notifications from "expo-notifications";
import Constants from "expo-constants";
import {triggerReviewAfterFirstMember} from "@/utils/reviewPrompt";

export type ActivityStatus = "active" | "recent" | "away" | "inactive";

export type FamilyMember = {
  id: string;
  userId: string;
  name: string;
  relation: string;
  avatar: string;
  status: ActivityStatus;
  lastSeen: Date;
  lastCheckInAt: Date | null;
  region: string;
  isMe?: boolean;
  pending?: boolean;
  travelMode?: boolean;
  travelDestination?: string;
  joinedAt?: string | null;
};

export type CheckInRequest = {
  id: string;
  memberId: string;
  memberName: string;
  timestamp: Date;
  responded: boolean;
  response?: "fine" | "help";
};

export type MyProfile = {
  name: string;
  region: string;
  timezone?: string;
};

type FamilyContextType = {
  members: FamilyMember[];
  checkInRequests: CheckInRequest[];
  myStatus: ActivityStatus;
  heartbeatIntervalLabel: string;
  myLastSeen: Date;
  myProfile: MyProfile | null;
  circleId: string;
  inviteCode: string;
  deviceId: string;
  isRegistered: boolean;
  plan: string;
  travelMode: boolean;
  travelDestination: string;
  isLoading: boolean;
  safetyEvents: ApiSafetyEvent[];
  patterns: ApiPattern | null;
  alertPrefs: AlertPrefs;
  shouldShowFounding: boolean;
  dismissFounding: () => void;
  addMember: (member: Omit<FamilyMember, "id" | "status" | "lastSeen" | "lastCheckInAt">) => void;
  removeMember: (id: string) => Promise<void>;
  clearAllState: () => Promise<void>;
  respondToCheckIn: (requestId: string, response: "fine" | "help") => void;
  sendHeartbeat: () => void;
  setMyProfile: (profile: MyProfile) => Promise<void>;
  pendingCheckIn: CheckInRequest | null;
  refreshCircle: () => Promise<void>;
  reloadCircleFromStorage: () => Promise<void>;
  setTravelMode: (on: boolean, destination?: string) => Promise<void>;
  upgradePlan: (plan: "monthly" | "annual") => Promise<void>;
  syncSubscription: () => Promise<void>;
  refreshSafetyEvents: () => Promise<void>;
  setAlertPref: (source: keyof AlertPrefs, enabled: boolean) => Promise<void>;
  bgRefreshDisabled: boolean;
  locationPermissionMissing: boolean;
};

const FamilyContext = createContext<FamilyContextType | null>(null);

const CHECKINS_KEY = "@ollia_checkins";
const PROFILE_KEY = "@ollia_my_profile";
const CIRCLE_KEY = "@ollia_circle_v2";
const INVITE_CODE_KEY = "@ollia_invite_code_v2";
const PLAN_KEY = "@ollia_plan";
const TRAVEL_KEY = "@ollia_travel";
const ALERT_PREFS_KEY = "@ollia_alert_prefs";
const PENDING_INVITE_KEY = "@ollia_pending_invite";

/** All @ollia_* storage keys — cleared on sign out to prevent cross-user data leaks */
const ALL_STORAGE_KEYS = [
  CHECKINS_KEY,
  PROFILE_KEY,
  CIRCLE_KEY,
  INVITE_CODE_KEY,
  PLAN_KEY,
  TRAVEL_KEY,
  ALERT_PREFS_KEY,
  PENDING_INVITE_KEY,
];

export type AlertPrefs = {
  usgs: boolean;
  noaa: boolean;
  gdacs: boolean;
};

const HEARTBEAT_INTERVAL_MS = 1800000;
const CIRCLE_REFRESH_MS = 1800000;
const SAFETY_REFRESH_MS = 15 * 60 * 1000;

function generateId(len = 20): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  return Array.from({ length: len }, () =>
      chars[Math.floor(Math.random() * chars.length)]
  ).join("");
}

function getStatusFromLastSeen(lastSeen: Date | null): ActivityStatus {
  if (!lastSeen) return "inactive";
  const diffMs = Date.now() - lastSeen.getTime();
  const diffMins = diffMs / (1000 * 60);
  if (diffMins < 30) return "active";
  if (diffMins < 60 * 3) return "recent";
  if (diffMins < 60 * 12) return "away";
  return "inactive";
}

function apiMemberToLocal(m: ApiCircleMember, meId: string): FamilyMember {
  const lastSeen = m.lastSeen ? new Date(m.lastSeen) : new Date(0);
  const lastCheckInAt = m.lastCheckInAt ? new Date(m.lastCheckInAt) : null;
  // Internal fallback only — the UI reads lastCheckInAt directly.
  const statusReference = lastCheckInAt ?? (m.lastSeen ? lastSeen : null);
  return {
    id: m.id,
    userId: m.userId,
    name: m.name,
    relation: m.relation,
    avatar: m.name[0]?.toUpperCase() ?? "?",
    status: getStatusFromLastSeen(statusReference),
    lastSeen,
    lastCheckInAt,
    region: m.region ?? "",
    isMe: m.userId === meId,
    pending: false,
    travelMode: m.travelMode ?? false,
    travelDestination: m.travelDestination,
    joinedAt: m.joinedAt
  };
}

export function FamilyProvider({ children }: { children: React.ReactNode }) {
  const { userId, getToken, isLoaded: authLoaded } = useAuth();
  const [deviceId, setDeviceId] = useState<string>("");
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [checkInRequests, setCheckInRequests] = useState<CheckInRequest[]>([]);
  const [myLastSeen, setMyLastSeen] = useState<Date>(new Date());
  const [myProfile, setMyProfileState] = useState<MyProfile | null>(null);
  const [circleId, setCircleId] = useState<string>("");
  const [inviteCode, setInviteCode] = useState<string>("");
  const [isRegistered, setIsRegistered] = useState(false);
  const [plan, setPlan] = useState<string>("free");
  const [travelMode, setTravelModeState] = useState(false);
  const [travelDestination, setTravelDestinationState] = useState("");
  const [safetyEvents, setSafetyEvents] = useState<ApiSafetyEvent[]>([]);
  const [patterns, setPatterns] = useState<ApiPattern | null>(null);
  const [alertPrefs, setAlertPrefsState] = useState<AlertPrefs>({ usgs: true, noaa: true, gdacs: true });
  const [isLoading, setIsLoading] = useState(true);
  const [bgRefreshDisabled, setBgRefreshDisabled] = useState(false);
  const [locationPermissionMissing, setLocationPermissionMissing] = useState(false);
  const [shouldShowFounding, setShouldShowFounding] = useState(false);

  const heartbeatRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const refreshRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const safetyRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const appStateRef = useRef<AppStateStatus>("active");
  const deviceIdRef = useRef<string>("");
  const circleIdRef = useRef<string>("");

  const prevUserIdRef = useRef<string | null>(null);

  const myStatus: ActivityStatus = getStatusFromLastSeen(myLastSeen);

  const heartbeatIntervalLabel = DETECTION_LABEL;

  const dismissFounding = useCallback(() => {
    setShouldShowFounding(false);
  }, []);

  const stopAllIntervals = useCallback(() => {
    if (heartbeatRef.current) { clearInterval(heartbeatRef.current); heartbeatRef.current = null; }
    if (refreshRef.current) { clearInterval(refreshRef.current); refreshRef.current = null; }
    if (safetyRef.current) { clearInterval(safetyRef.current); safetyRef.current = null; }
  }, []);

  const registerPushNotifications = useCallback(async () => {
    if (Platform.OS === "web") return;
    try {
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== "granted") return;

      // Register notification action category for nudge notifications
      if (Platform.OS === 'ios') {
        await Notifications.setNotificationCategoryAsync("CHECKIN_NUDGE", [
          {
            identifier: "IM_OKAY",
            buttonTitle: "I'm okay 💛",
            options: {
              isDestructive: false,
              isAuthenticationRequired: false,
              opensAppToForeground: false,
            },
          },
        ]);
      }

      const projectId = Constants.expoConfig?.extra?.eas?.projectId as string | undefined;
      if (!projectId) return;
      const { data: token } = await Notifications.getExpoPushTokenAsync({ projectId });
      await api.registerPushToken(token);
    } catch (e) {
      console.log("Push registration error:", e);
    }
  }, []);

  /** Wipe all local state and AsyncStorage — call on sign out or user switch */
  const clearAllState = useCallback(async () => {
    stopAllIntervals();
    // Remove push token from backend before clearing auth
    // TODO We keep the token in order to notify the user
    // api.deregisterPushToken().catch(() => {});
    // Tear down background tasks
    unregisterBackgroundActivity().catch(() => {});
    // Clear AsyncStorage — also clear any per-user founding claim keys
    await AsyncStorage.multiRemove(ALL_STORAGE_KEYS);
    // Reset all in-memory state
    setDeviceId("");
    setMembers([]);
    setCheckInRequests([]);
    setMyLastSeen(new Date());
    setMyProfileState(null);
    setCircleId("");
    setInviteCode("");
    setIsRegistered(false);
    setPlan("free");
    setTravelModeState(false);
    setTravelDestinationState("");
    setSafetyEvents([]);
    setPatterns(null);
    setAlertPrefsState({ usgs: true, noaa: true, gdacs: true });
    setShouldShowFounding(false);
    setIsLoading(false);
    // Clear refs
    deviceIdRef.current = "";
    circleIdRef.current = "";
    setAuthTokenGetter(null);
  }, [stopAllIntervals]);

  const sendHeartbeatToServer = useCallback(async (uid: string) => {
    if (!uid) return;
    try {
      await api.sendHeartbeat(uid, "heartbeat");
      setMyLastSeen(new Date());
    } catch (e) {
      console.warn("Heartbeat failed:", e);
    }
  }, []);

  const refreshSafetyEvents = useCallback(async () => {
    try {
      const events = await api.getSafetyEvents();
      setSafetyEvents(events);
    } catch (e) {
      console.warn("Safety events failed:", e);
    }
  }, []);

  const refreshPatterns = useCallback(async (uid: string) => {
    if (!uid) return;
    try {
      const p = await api.getPatterns(uid);
      setPatterns(p);
    } catch (e) {
      console.warn("Patterns failed:", e);
    }
  }, []);

  const refreshCircle = useCallback(async () => {
    const cId = circleIdRef.current;
    const devId = deviceIdRef.current;
    if (!cId || !devId) return;
    try {
      const data = await api.getCircle(cId);

      // Always sync inviteCode from server
      if (data.inviteCode) {
        setInviteCode(data.inviteCode);
        await AsyncStorage.setItem(INVITE_CODE_KEY, data.inviteCode);
      }

      const remoteMembers = data.members
          .filter((m) => m.userId !== devId)
          .map((m) => apiMemberToLocal(m, devId));
      setMembers(remoteMembers);

      // Prompt the current user to reach out to peers whose last human check-in
      // is over 18h old. Based on lastCheckInAt so passive signals don't hide it.
      const staleThresholdMs = 1000 * 60 * 60 * 18;
      const stale = remoteMembers.filter(
          (m) => m.lastCheckInAt && Date.now() - m.lastCheckInAt.getTime() > staleThresholdMs
      );
      if (stale.length > 0) {
        setCheckInRequests((prev) => {
          const existingIds = new Set(prev.map((c) => c.memberId));
          const newRequests = stale
              .filter((m) => !existingIds.has(m.id))
              .map((m) => ({
                id: `ci_${m.id}_${Date.now()}`,
                memberId: m.id,
                memberName: m.name,
                timestamp: new Date(),
                responded: false,
              }));
          return newRequests.length > 0 ? [...prev, ...newRequests] : prev;
        });
      }
    } catch (e) {
      console.warn("Circle refresh failed:", e);
    }
  }, []);

  const startHeartbeat = useCallback(
      (uid: string) => {
        if (heartbeatRef.current) clearInterval(heartbeatRef.current);
        sendHeartbeatToServer(uid);
        heartbeatRef.current = setInterval(
            () => sendHeartbeatToServer(uid),
            HEARTBEAT_INTERVAL_MS
        );
      },
      [sendHeartbeatToServer]
  );

  const startRefresh = useCallback(() => {
    if (refreshRef.current) clearInterval(refreshRef.current);
    refreshCircle();
    refreshRef.current = setInterval(refreshCircle, CIRCLE_REFRESH_MS);
  }, [refreshCircle]);

  const startSafetyRefresh = useCallback(() => {
    if (safetyRef.current) clearInterval(safetyRef.current);
    refreshSafetyEvents();
    safetyRef.current = setInterval(refreshSafetyEvents, SAFETY_REFRESH_MS);
  }, [refreshSafetyEvents]);

  const syncSubscription = useCallback(async () => {
    try {
      const status = await api.getSubscriptionStatus();
      setPlan(status.plan);
      await AsyncStorage.setItem(PLAN_KEY, status.plan);
    } catch (e) {
      console.warn("syncSubscription failed:", e);
    }
  }, []);

  /** Check founding member status — call after any refresh of server user */
  const checkFoundingStatus = useCallback(async (uid: string) => {
    try {
      const serverUser = await api.getMe();
      if (serverUser?.foundingMember && !serverUser?.foundingClaimedAt) {
        setShouldShowFounding(true);
      }
    } catch (e) {
      console.warn("checkFoundingStatus failed:", e);
    }
  }, []);

  useEffect(() => {
    const sub = AppState.addEventListener("change", (next: AppStateStatus) => {
      const prev = appStateRef.current;
      appStateRef.current = next;
      if (
          (prev === "background" || prev === "inactive") &&
          next === "active"
      ) {
        sendHeartbeatToServer(deviceIdRef.current);
        refreshCircle();
        syncSubscription();
        // Re-check founding status in case DB was just updated
        if (deviceIdRef.current) checkFoundingStatus(deviceIdRef.current);
        // Refresh cached auth token for background tasks
        getToken().then((t: string | null) => storeBackgroundToken(t)).catch(() => {});
        // Re-register push token in case it changed
        registerPushNotifications();
        // Check background refresh status & location permission
        if (Platform.OS !== "web") {
          BackgroundFetch.getStatusAsync().then((s) => {
            setBgRefreshDisabled(
                s === BackgroundFetch.BackgroundFetchStatus.Restricted ||
                s === BackgroundFetch.BackgroundFetchStatus.Denied
            );
          }).catch(() => {});
          hasBackgroundLocationPermission().then((granted) => {
            setLocationPermissionMissing(!granted);
          }).catch(() => {});
        }
      }
    });

    // Handle notification action buttons (e.g. "I'm okay 💛" from nudge notification)
    const responseSub = Notifications.addNotificationResponseReceivedListener((response) => {
      if (response.actionIdentifier === "IM_OKAY") {
        sendHeartbeatToServer(deviceIdRef.current);
      }
    });

    return () => {
      sub.remove();
      responseSub.remove();
      stopAllIntervals();
    };
  }, [sendHeartbeatToServer, refreshCircle, syncSubscription, registerPushNotifications, checkFoundingStatus]);

  // Listen for ollia://heartbeat deep links (e.g. from iOS Shortcuts)
  useEffect(() => {
    function handleUrl({ url }: { url: string }) {
      if (url === "ollia://heartbeat" || url.startsWith("ollia://heartbeat")) {
        sendHeartbeatToServer(deviceIdRef.current);
      }
    }
    const sub = Linking.addEventListener("url", handleUrl);
    // Also check the initial URL (cold start from deep link)
    Linking.getInitialURL().then((url) => {
      if (url) handleUrl({ url });
    });
    return () => sub.remove();
  }, [sendHeartbeatToServer]);

  const setupCircle = useCallback(
      async (devId: string) => {
        let cId = await AsyncStorage.getItem(CIRCLE_KEY) ?? "";
        let code = await AsyncStorage.getItem(INVITE_CODE_KEY) ?? "";
        if (!cId) {
          try {
            const circle = await api.createCircle(devId);
            cId = circle.id;
            code = circle.inviteCode;
            await AsyncStorage.setItem(CIRCLE_KEY, cId);
            await AsyncStorage.setItem(INVITE_CODE_KEY, code);
          } catch (e) {
            console.warn("createCircle failed:", e);
          }
        }
        // If we have a circleId but no inviteCode, fetch it from the server
        if (cId && !code) {
          try {
            const circle = await api.getCircle(cId);
            code = circle.inviteCode;
            if (code) {
              await AsyncStorage.setItem(INVITE_CODE_KEY, code);
            }
          } catch (e) {
            console.warn("Failed to fetch inviteCode:", e);
          }
        }

        circleIdRef.current = cId;
        setCircleId(cId);
        setInviteCode(code);
        return cId;
      },
      []
  );

  const bootstrap = useCallback(async (uid: string) => {
    if (!uid) return;
    deviceIdRef.current = uid;
    setDeviceId(uid);

    try {
      const savedPlan = await AsyncStorage.getItem(PLAN_KEY);
      if (savedPlan) setPlan(savedPlan);

      const travelStr = await AsyncStorage.getItem(TRAVEL_KEY);
      if (travelStr) {
        const t = JSON.parse(travelStr);
        setTravelModeState(t.on ?? false);
        setTravelDestinationState(t.destination ?? "");
      }

      const alertPrefsStr = await AsyncStorage.getItem(ALERT_PREFS_KEY);
      if (alertPrefsStr) {
        setAlertPrefsState(JSON.parse(alertPrefsStr));
      }

      const profileStr = await AsyncStorage.getItem(PROFILE_KEY);
      let serverUser: Awaited<ReturnType<typeof api.getMe>> | null = null;
      if (profileStr) {
        const profile = JSON.parse(profileStr) as MyProfile;
        setMyProfileState(profile);
        try {
          await api.upsertUser({
            id: uid,
            name: profile.name,
            region: profile.region,
            timezone: profile.timezone,
          });
          setIsRegistered(true);
        } catch (e) {
          console.warn("upsertUser failed:", e);
        }
        try {
          serverUser = await api.getMe();
        } catch (e) {
          console.warn("getMe (after upsert) failed:", e);
        }
      } else {
        try {
          serverUser = await api.getMe();
          if (serverUser?.name) {
            const profile: MyProfile = { name: serverUser.name, region: serverUser.region ?? "" };
            setMyProfileState(profile);
            await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
            setIsRegistered(true);
          }
        } catch (e) {
          console.warn("getMe failed:", e);
        }
      }

      // Founding member welcome — show once per device+account.
      // Flip the flag and let _layout.tsx handle the navigation reactively
      // once the router is ready.
      if (serverUser?.foundingMember && !serverUser?.foundingClaimedAt) {
        setShouldShowFounding(true);
      }

      const cId = await setupCircle(uid);
      if (cId) {
        startHeartbeat(uid);
        startRefresh();
        refreshPatterns(uid);
      }

      // Register background activity detection (background fetch + location triggers)
      registerBackgroundActivity(uid).catch(() => {});
      // Cache the current auth token for background tasks
      getToken().then((t: string | null) => storeBackgroundToken(t)).catch(() => {});
      // Register push notification token with backend
      registerPushNotifications();

      setIsLoading(false);

      // Check background refresh & location permission status
      if (Platform.OS !== "web") {
        BackgroundFetch.getStatusAsync().then((s) => {
          setBgRefreshDisabled(
              s === BackgroundFetch.BackgroundFetchStatus.Restricted ||
              s === BackgroundFetch.BackgroundFetchStatus.Denied
          );
        }).catch(() => {});

        hasBackgroundLocationPermission().then((granted) => {
          setLocationPermissionMissing(!granted);
        }).catch(() => {});
      }

      // Sync subscription status from server (authoritative source for plan).
      // Founding members get "premium" here via effectivePlan() on the backend.
      try {
        const status = await api.getSubscriptionStatus();
        setPlan(status.plan);
        await AsyncStorage.setItem(PLAN_KEY, status.plan);
      } catch (e) {
        console.warn("getSubscriptionStatus failed:", e);
      }

      startSafetyRefresh();

      const checkins = await AsyncStorage.getItem(CHECKINS_KEY);
      if (checkins) {
        setCheckInRequests(
            JSON.parse(checkins).map((c: CheckInRequest) => ({
              ...c,
              timestamp: new Date(c.timestamp),
            }))
        );
      }
    } catch (e) {
      console.error("Bootstrap error:", e);
      setIsLoading(false);
    }
  }, [setupCircle, startHeartbeat, startRefresh, startSafetyRefresh, refreshPatterns, syncSubscription, registerPushNotifications]);

  useEffect(() => {
    if (!authLoaded) return;

    const prevUserId = prevUserIdRef.current;
    prevUserIdRef.current = userId ?? null;

    if (!userId) {
      // Signed out — clear everything
      clearAllState();
      return;
    }

    // User changed (sign out then sign in as different user)
    if (prevUserId && prevUserId !== userId) {
      clearAllState().then(() => {
        setAuthTokenGetter(getToken);
        bootstrap(userId);
      });
      return;
    }

    setAuthTokenGetter(getToken);
    bootstrap(userId);
  }, [userId, authLoaded]);

  const addMember = useCallback(
      (member: Omit<FamilyMember, "id" | "status" | "lastSeen" | "lastCheckInAt">) => {
        const newMember: FamilyMember = {
          ...member,
          id: generateId(8),
          status: "inactive",
          lastSeen: new Date(0),
          lastCheckInAt: null,
        };
        setMembers((prev) => [...prev, newMember]);
      },
      []
  );

  const removeMember = useCallback(async (id: string) => {
    const cId = circleIdRef.current;
    if (!cId) {
      console.warn("removeMember: no circleId");
      return;
    }
    try {
      await api.removeMember(cId, id);
      setMembers((prev) => prev.filter((m) => m.id !== id));
    } catch (e: any) {
      console.error("removeMember failed:", e);
      throw e;
    }
  }, []);

  const respondToCheckIn = useCallback(
      async (requestId: string, response: "fine" | "help") => {
        const devId = deviceIdRef.current;
        if (devId) {
          api.sendHeartbeat(devId, "check_in_response").catch(() => {});
        }
        setCheckInRequests((prev) => {
          const updated = prev.map((c) =>
              c.id === requestId ? { ...c, responded: true, response } : c
          );
          AsyncStorage.setItem(CHECKINS_KEY, JSON.stringify(updated));
          return updated;
        });
        setMyLastSeen(new Date());
      },
      []
  );

  const sendHeartbeat = useCallback(() => {
    setMyLastSeen(new Date());
    sendHeartbeatToServer(deviceIdRef.current);
  }, [sendHeartbeatToServer]);

  const setMyProfile = useCallback(
      async (profile: MyProfile) => {
        setMyProfileState(profile);
        await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile));

        const devId = deviceIdRef.current;
        if (!devId) return;

        try {
          await api.upsertUser({
            id: devId,
            name: profile.name,
            region: profile.region,
            timezone: profile.timezone,
          });
          setIsRegistered(true);
        } catch (e) {
          console.warn("upsertUser failed:", e);
        }

        const cId = await setupCircle(devId);
        if (cId) {
          startHeartbeat(devId);
          startRefresh();
          refreshPatterns(devId);
        }
      },
      [setupCircle, startHeartbeat, startRefresh, refreshPatterns]
  );

  const setTravelMode = useCallback(
      async (on: boolean, destination?: string) => {
        const devId = deviceIdRef.current;
        setTravelModeState(on);
        setTravelDestinationState(on ? (destination ?? "") : "");
        await AsyncStorage.setItem(
            TRAVEL_KEY,
            JSON.stringify({ on, destination: destination ?? "" })
        );
        if (devId) {
          try {
            await api.setTravelMode(devId, on, destination);
          } catch (e) {
            console.warn("setTravelMode failed:", e);
          }
        }
      },
      []
  );

  const upgradePlan = async (plan: "monthly" | "annual") => {
    // RevenueCat handles the purchase — just refresh the user's plan from backend
    await syncSubscription();
  };

  const reloadCircleFromStorage = useCallback(async () => {
    const uid = deviceIdRef.current || userId;
    if (!uid) return;
    if (!deviceIdRef.current) {
      deviceIdRef.current = uid;
      setDeviceId(uid);
    }
    const cId = await AsyncStorage.getItem(CIRCLE_KEY) ?? "";
    const code = await AsyncStorage.getItem(INVITE_CODE_KEY) ?? "";
    if (!cId) return;
    circleIdRef.current = cId;
    setCircleId(cId);
    setInviteCode(code);
    try {
      const circle = await api.getCircle(cId);
      if (circle.members) {
        const mapped = circle.members.map((m: ApiCircleMember) => apiMemberToLocal(m, uid));
        setMembers(mapped);

        if (mapped.length === 1) {
          const firstMember = mapped[0];
          const joinedAt = firstMember.joinedAt ? new Date(firstMember.joinedAt) : null;
          const isToday = joinedAt && (Date.now() - joinedAt.getTime()) < 1000 * 60 * 60 * 24;
          if (isToday) {
            await triggerReviewAfterFirstMember();
          }
        }
      }
    } catch (e) {
      console.warn("reloadCircleFromStorage fetch failed:", e);
    }
  }, [userId]);

  const setAlertPref = useCallback(async (source: keyof AlertPrefs, enabled: boolean) => {
    setAlertPrefsState((prev) => {
      const next = { ...prev, [source]: enabled };
      AsyncStorage.setItem(ALERT_PREFS_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const prefFilteredEvents = safetyEvents.filter((e) => {
    if (e.source === "USGS" && !alertPrefs.usgs) return false;
    if (e.source === "NOAA" && !alertPrefs.noaa) return false;
    if (e.source === "GDACS" && !alertPrefs.gdacs) return false;
    return true;
  });

  const activeLocation = travelMode && travelDestination
      ? travelDestination
      : (myProfile?.region ?? "");

  const toCountry = (location: string): string =>
      location.includes(",")
          ? location.split(",").pop()?.trim().toLowerCase() ?? ""
          : location.trim().toLowerCase();

  const userCountry = toCountry(activeLocation);

  // Build a set of all relevant countries: current user + every circle member that has a region
  const relevantCountries = new Set<string>(userCountry ? [userCountry] : []);
  for (const m of members) {
    if (m.region) {
      const c = toCountry(m.region);
      if (c) relevantCountries.add(c);
    }
  }

  const isUsRelated = [...relevantCountries].some(
      (c) => c === "us" || c === "usa" || c.includes("united states"),
  );

  // City-filtered alerts are a Premium feature — free users always see global alerts
  const filteredSafetyEvents = (plan === "premium" && relevantCountries.size > 0)
      ? prefFilteredEvents.filter((e) => {
        if (e.source === "NOAA") {
          return isUsRelated;
        }
        const haystack = `${e.region ?? ""} ${e.title ?? ""}`.toLowerCase();
        return [...relevantCountries].some((c) => haystack.includes(c));
      })
      : prefFilteredEvents;

  const pendingCheckIn = checkInRequests.find((c) => !c.responded) ?? null;

  return (
      <FamilyContext.Provider
          value={{
            members,
            checkInRequests,
            myStatus,
            heartbeatIntervalLabel,
            myLastSeen,
            myProfile,
            circleId,
            inviteCode,
            deviceId,
            isRegistered,
            isLoading,
            plan,
            travelMode,
            travelDestination,
            safetyEvents: filteredSafetyEvents,
            patterns,
            alertPrefs,
            shouldShowFounding,
            dismissFounding,
            addMember,
            removeMember,
            clearAllState,
            respondToCheckIn,
            sendHeartbeat,
            setMyProfile,
            pendingCheckIn,
            refreshCircle,
            reloadCircleFromStorage,
            setTravelMode,
            upgradePlan,
            syncSubscription,
            refreshSafetyEvents,
            setAlertPref,
            bgRefreshDisabled,
            locationPermissionMissing,
          }}
      >
        {children}
      </FamilyContext.Provider>
  );
}

export function useFamilyContext(): FamilyContextType {
  const ctx = useContext(FamilyContext);
  if (!ctx)
    throw new Error("useFamilyContext must be used within FamilyProvider");
  return ctx;
}